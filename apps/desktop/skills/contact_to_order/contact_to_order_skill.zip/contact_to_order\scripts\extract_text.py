#!/usr/bin/env python3
"""contact_to_order: local text extraction + Ollama LLM parse + JSON normalize.

Default pipeline (matches Dify DSL + model_routes.yaml):
  1. Classify attachment as image or document.
  2. For documents, extract plain text locally (PDF/DOCX/XLSX/...).
  3. Call Ollama OpenAI-compatible /v1/chat/completions with routed model/options.
  4. Clean model output via clean_contact_to_order_json.py rules.

Usage:
  python extract_text.py <attachment_path> [--issmple 0] [--callback-url URL]
  python extract_text.py <attachment_path> --extract-only

Hermes Agent: pass a on-disk path only (from chat-attachments index storage_path).
Never paste PDF/binary from chat into execute_code or Python strings.
"""
from __future__ import annotations

import argparse
import base64
import csv
import importlib.util
import json
import mimetypes
import re
import sys
import urllib.error
import urllib.request
from pathlib import Path
from typing import Any
from urllib.parse import urlparse
from urllib.parse import quote as url_quote

TEXT_EXTS = {".txt", ".md", ".csv", ".json", ".yaml", ".yml", ".log"}
IMAGE_EXTS = {".jpg", ".jpeg", ".png", ".webp", ".bmp", ".tif", ".tiff", ".gif"}
DOCUMENT_EXTS = TEXT_EXTS | {".pdf", ".docx", ".xlsx", ".csv"}

SKILL_ROOT = Path(__file__).resolve().parent.parent
ROUTES_PATH = SKILL_ROOT / "model_routes.yaml"
PROMPT_PATH = SKILL_ROOT / "prompts" / "contact_to_order_prompt.md"
CLEAN_SCRIPT = Path(__file__).resolve().parent / "clean_contact_to_order_json.py"
DEFAULT_ISSMPLE = 0
HTTP_TIMEOUT_SEC = 600
MAX_WEB_URL_LEN = 12000


def emit(payload: dict[str, Any]) -> None:
    print(json.dumps(payload, ensure_ascii=False, indent=2))


def _default_routes() -> dict[str, Any]:
    return {
        "server": {
            "url": "http://192.168.70.249:11434/v1",
            "provider": "ollama",
            "api_format": "openai-compatible",
        },
        "models": {
            "image": {
                "0": {
                    "model": "qwen2.5vl:7b",
                    "num_ctx": 5048,
                    "num_predict": 5048,
                },
                "default": {
                    "model": "qwen3-vl:30b",
                    "num_ctx": 5048,
                    "num_predict": 5048,
                },
            },
            "document": {
                "0": {
                    "model": "qwen2.5vl:7b",
                    "num_ctx": 20480,
                    "num_predict": 10240,
                },
                "default": {
                    "model": "qwen3-vl:30b",
                    "num_ctx": 20480,
                    "num_predict": 10240,
                },
            },
        },
    }


def load_model_routes() -> dict[str, Any]:
    if not ROUTES_PATH.exists():
        return _default_routes()
    raw = ROUTES_PATH.read_text(encoding="utf-8")
    try:
        import yaml  # type: ignore

        data = yaml.safe_load(raw)
        return data if isinstance(data, dict) else _default_routes()
    except Exception:  # noqa: BLE001
        return _default_routes()


def select_route(routes: dict[str, Any], file_kind: str, issmple: int) -> dict[str, Any]:
    server = routes.get("server") or {}
    branch = (routes.get("models") or {}).get(file_kind) or {}
    route_key = "0" if issmple == 0 else "default"
    model_cfg = branch.get(route_key) or branch.get("default") or {}
    return {
        "base_url": str(server.get("url", "http://192.168.70.249:11434/v1")).rstrip("/"),
        "model": str(model_cfg.get("model", "qwen2.5vl:7b")),
        "num_ctx": int(model_cfg.get("num_ctx", 5048)),
        "num_predict": int(model_cfg.get("num_predict", 5048)),
        "file_kind": file_kind,
        "issmple": issmple,
        "route_key": route_key,
    }


def load_prompt_sections() -> tuple[str, str]:
    if not PROMPT_PATH.exists():
        raise FileNotFoundError(f"prompt not found: {PROMPT_PATH}")
    text = PROMPT_PATH.read_text(encoding="utf-8")
    system = ""
    user_rules = ""
    if "## System" in text:
        after_system = text.split("## System", 1)[1]
        if "## User Rules" in after_system:
            system, user_rules = after_system.split("## User Rules", 1)
        else:
            system = after_system
    system = system.strip()
    user_rules = user_rules.strip()
    return system, user_rules


def read_plain(path: Path) -> str:
    return path.read_text(encoding="utf-8", errors="ignore")


def read_csv(path: Path) -> str:
    rows = []
    with path.open("r", encoding="utf-8", errors="ignore", newline="") as f:
        for row in csv.reader(f):
            rows.append("\t".join(row))
    return "\n".join(rows)


def read_pdf(path: Path) -> str:
    try:
        from pypdf import PdfReader  # type: ignore
    except Exception:  # noqa: BLE001
        try:
            from PyPDF2 import PdfReader  # type: ignore
        except Exception as exc:  # noqa: BLE001
            raise RuntimeError("PDF extraction requires pypdf or PyPDF2") from exc
    reader = PdfReader(str(path))
    return "\n".join((page.extract_text() or "") for page in reader.pages)


def read_docx(path: Path) -> str:
    try:
        import docx  # type: ignore
    except Exception as exc:  # noqa: BLE001
        raise RuntimeError("DOCX extraction requires python-docx") from exc
    doc = docx.Document(str(path))
    parts = [p.text for p in doc.paragraphs]
    for table in doc.tables:
        for row in table.rows:
            parts.append("\t".join(cell.text for cell in row.cells))
    return "\n".join(parts)


def read_xlsx(path: Path) -> str:
    try:
        import openpyxl  # type: ignore
    except Exception as exc:  # noqa: BLE001
        raise RuntimeError("XLSX extraction requires openpyxl") from exc
    wb = openpyxl.load_workbook(str(path), data_only=True, read_only=True)
    parts = []
    for ws in wb.worksheets:
        parts.append(f"# Sheet: {ws.title}")
        for row in ws.iter_rows(values_only=True):
            parts.append("\t".join("" if v is None else str(v) for v in row))
    return "\n".join(parts)


def classify_file(path: Path) -> str:
    ext = path.suffix.lower()
    if ext in IMAGE_EXTS:
        return "image"
    if ext in DOCUMENT_EXTS or ext == ".pdf":
        return "document"
    return "unsupported"


def extract_document_text(path: Path) -> str:
    ext = path.suffix.lower()
    if ext == ".csv":
        return read_csv(path)
    if ext in TEXT_EXTS:
        return read_plain(path)
    if ext == ".pdf":
        return read_pdf(path)
    if ext == ".docx":
        return read_docx(path)
    if ext == ".xlsx":
        return read_xlsx(path)
    raise RuntimeError(f"unsupported document suffix: {ext}")


def image_data_url(path: Path) -> str:
    mime = mimetypes.guess_type(str(path))[0] or "image/jpeg"
    encoded = base64.standard_b64encode(path.read_bytes()).decode("ascii")
    return f"data:{mime};base64,{encoded}"


def call_ollama_chat(
    route: dict[str, Any],
    *,
    system: str,
    user_text: str,
    image_path: Path | None = None,
) -> str:
    url = f"{route['base_url']}/chat/completions"
    if image_path is not None:
        user_content: Any = [
            {"type": "text", "text": user_text},
            {"type": "image_url", "image_url": {"url": image_data_url(image_path)}},
        ]
    else:
        user_content = user_text

    payload = {
        "model": route["model"],
        "messages": [
            {"role": "system", "content": system},
            {"role": "user", "content": user_content},
        ],
        "stream": False,
        "options": {
            "num_ctx": route["num_ctx"],
            "num_predict": route["num_predict"],
        },
    }
    body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    req = urllib.request.Request(
        url,
        data=body,
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=HTTP_TIMEOUT_SEC) as resp:
            data = json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        detail = exc.read().decode("utf-8", errors="ignore")
        raise RuntimeError(f"ollama HTTP {exc.code}: {detail[:2000]}") from exc
    except urllib.error.URLError as exc:
        raise RuntimeError(f"ollama unreachable at {url}: {exc}") from exc

    choices = data.get("choices") or []
    if not choices:
        raise RuntimeError(f"ollama empty choices: {json.dumps(data, ensure_ascii=False)[:2000]}")
    message = choices[0].get("message") or {}
    content = message.get("content", "")
    if isinstance(content, list):
        parts = []
        for block in content:
            if isinstance(block, dict) and block.get("type") == "text":
                parts.append(str(block.get("text", "")))
        content = "\n".join(parts)
    if not str(content).strip():
        raise RuntimeError("ollama returned empty content")
    return str(content)


def load_clean_module():
    spec = importlib.util.spec_from_file_location("clean_contact_to_order_json", CLEAN_SCRIPT)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"cannot load cleaner: {CLEAN_SCRIPT}")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def normalize_model_output(raw: str) -> dict[str, Any]:
    clean = load_clean_module()
    obj = clean.parse_jsonish(raw)
    return clean.normalize_order(obj)


def is_valid_orderinfo(orderinfo: Any) -> bool:
    if not isinstance(orderinfo, list) or len(orderinfo) == 0:
        return False
    return all(isinstance(row, dict) for row in orderinfo)


def validate_callback_url(callback_url: str) -> str:
    url = callback_url.strip()
    if not url:
        raise ValueError("callbackURL 不能为空")
    parsed = urlparse(url)
    if parsed.scheme not in ("http", "https"):
        raise ValueError("callbackURL 必须使用 http 或 https")
    if not parsed.netloc:
        raise ValueError("callbackURL 缺少有效主机名")
    if re.search(r"[\s<>\"']", url):
        raise ValueError("callbackURL 含有非法字符")
    return url


def encode_uri_component(value: str) -> str:
    """JavaScript encodeURIComponent 等价实现。"""
    return url_quote(value, safe="")


def build_web_url(callback_url: str, orderinfo: list[dict[str, Any]]) -> str:
    base = validate_callback_url(callback_url)
    post_data = {"tempType": orderinfo}
    json_str = json.dumps(post_data, ensure_ascii=False, separators=(",", ":"))
    json_data = encode_uri_component(json_str)
    web_url = f"{base}{json_data}"
    parsed = urlparse(web_url)
    if parsed.scheme not in ("http", "https") or not parsed.netloc:
        raise ValueError("拼接后的 WebUrl 无效")
    if len(web_url) > MAX_WEB_URL_LEN:
        raise ValueError(f"WebUrl 过长（>{MAX_WEB_URL_LEN} 字符），请缩短 callbackURL 或减小报文")
    return web_url


def apply_callback(payload: dict[str, Any], callback_url: str | None) -> None:
    if not callback_url:
        return
    orderinfo = payload.get("orderinfo")
    if not is_valid_orderinfo(orderinfo):
        payload["callback_applied"] = False
        payload["callback_error"] = "orderinfo 无效或为空，未生成 WebUrl"
        return
    try:
        web_url = build_web_url(callback_url, orderinfo)
        payload["callback_applied"] = True
        payload["web_url"] = web_url
        payload["post_data"] = {"tempType": orderinfo}
    except ValueError as exc:
        payload["callback_applied"] = False
        payload["callback_error"] = str(exc)


def run_extract_only(path: Path) -> None:
    file_kind = classify_file(path)
    mime = mimetypes.guess_type(str(path))[0]
    ext = path.suffix.lower()
    if file_kind == "image":
        emit({
            "ok": True,
            "mode": "extract_only",
            "file_type": "image",
            "mime": mime,
            "text": "",
            "note": "Image text is not extracted locally; use default mode for Ollama vision parse.",
        })
        return
    if file_kind == "unsupported":
        emit({"ok": False, "error": "unsupported_file_type", "suffix": ext, "mime": mime})
        return
    text = extract_document_text(path)
    emit({
        "ok": True,
        "mode": "extract_only",
        "file_type": "document",
        "mime": mime,
        "chars": len(text),
        "text": text,
    })


def run_llm_parse(path: Path, issmple: int, callback_url: str | None = None) -> None:
    file_kind = classify_file(path)
    mime = mimetypes.guess_type(str(path))[0]
    ext = path.suffix.lower()
    if file_kind == "unsupported":
        emit({"ok": False, "error": "unsupported_file_type", "suffix": ext, "mime": mime})
        return

    routes = load_model_routes()
    route = select_route(routes, file_kind, issmple)
    system_prompt, user_rules = load_prompt_sections()

    document_text = ""
    if file_kind == "document":
        try:
            document_text = extract_document_text(path)
        except Exception as exc:  # noqa: BLE001
            emit({
                "ok": False,
                "error": "extract_failed",
                "message": str(exc),
                "file": str(path),
            })
            return
        if not document_text.strip():
            emit({
                "ok": False,
                "error": "empty_document_text",
                "message": "No text extracted; convert to searchable PDF/TXT or use OCR.",
                "file": str(path),
            })
            return

    user_body = user_rules
    if file_kind == "document":
        user_body = (
            f"{user_rules}\n\n"
            "以下是从采购合同/订单附件中抽取的文本，请仅根据该文本提取订单 JSON：\n\n"
            f"{document_text}"
        )
    else:
        user_body = f"{user_rules}\n\n请根据附件图片提取订单 JSON。"

    try:
        raw = call_ollama_chat(
            route,
            system=system_prompt,
            user_text=user_body,
            image_path=path if file_kind == "image" else None,
        )
        normalized = normalize_model_output(raw)
    except Exception as exc:  # noqa: BLE001
        emit({
            "ok": False,
            "error": "llm_parse_failed",
            "message": str(exc),
            "file": str(path),
            "route": route,
        })
        return

    payload: dict[str, Any] = {
        "ok": True,
        "file": path.name,
        "file_type": file_kind,
        "mime": mime,
        "route": route,
        **normalized,
    }
    apply_callback(payload, callback_url)
    emit(payload)


def parse_args(argv: list[str]) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="contact_to_order Ollama contract parser")
    parser.add_argument("file_path", help="Path to contract attachment")
    parser.add_argument(
        "--issmple",
        type=int,
        default=DEFAULT_ISSMPLE,
        help="0 -> qwen2.5vl route; non-zero -> qwen3-vl route (Dify compat name)",
    )
    parser.add_argument(
        "--extract-only",
        action="store_true",
        help="Only run local text extraction (no Ollama call)",
    )
    parser.add_argument(
        "--callback-url",
        "--callbackURL",
        dest="callback_url",
        default=None,
        metavar="URL",
        help="Callback base URL; on success appends encodeURIComponent(JSON.stringify({tempType:orderinfo}))",
    )
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> None:
    args = parse_args(argv or sys.argv[1:])
    path = Path(args.file_path).expanduser().resolve()
    if not path.exists():
        emit({"ok": False, "error": "file_not_found", "file": str(path)})
        return
    if args.extract_only:
        run_extract_only(path)
        return
    run_llm_parse(path, args.issmple, callback_url=args.callback_url)


if __name__ == "__main__":
    main()
