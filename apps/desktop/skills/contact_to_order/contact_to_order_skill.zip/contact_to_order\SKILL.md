---
name: contact_to_order
description: "Parse procurement contracts/PO attachments into order JSON via Ollama; supports Hermes Panel attachments and callback WebUrl."
version: 1.1.0
author: Hermes Agent
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [contract, order, pdf, ocr, ollama, procurement, contact_to_order]
    related_skills: [hermes-agent]
---

# contact_to_order

## 目标

将客户上传的电子元器件采购合同、采购订单、合同截图、PDF、Word、Excel、图片等附件解析为稳定可读的订单 JSON。

本 skill 由 Dify DSL「合同解析V1.0-客户」迁移而来，保留原工作流的分支规则、字段规则、模型选择逻辑与最终 JSON 清理逻辑。

## 触发条件

当用户上传采购合同、采购订单、PO、销售合同、合同截图，并要求“解析合同”“生成订单 JSON”“合同转订单”“contact_to_order”时，启用本 skill。

典型输入：

```text
使用 contact_to_order 解析附件，issmple=0
```

带回调地址（解析成功后生成可点击的导入链接）：

```text
使用 contact_to_order 解析附件，issmple=0，callbackURL=https://your-app.example.com/import?data=
```

如用户没有提供 `issmple`，默认按 `issmple=0` 执行；如附件缺失，先要求用户上传合同附件。如用户提供了 `callbackURL` / `callbackUrl`，必须在调用脚本时传入 `--callback-url`。

## 输入参数

| 参数 | 类型 | 必填 | 说明 |
|---|---:|---:|---|
| uploadfile | file | 是 | 用户上传的采购合同/PO/订单附件。支持 image/document。 |
| issmple | number | 否 | 保留 Dify 原变量名。`0` 使用 2.5 路线；非 `0` 使用 3.0 路线。默认 `0`。 |
| callbackURL | string | 否 | 回调基础 URL（须 `http`/`https`）。解析成功且 `orderinfo` 有效时，脚本拼接 `encodeURIComponent(JSON.stringify(postData))` 生成 `WebUrl`；`postData.tempType` = `orderinfo`。用户须在 URL 末尾自行带上查询参数前缀（如 `?data=`），脚本只做 `callbackURL + jsonData` 拼接。 |

## Dify 到 Hermes 的节点映射

| Dify 节点 | Hermes skill 步骤 |
|---|---|
| 上传附件 | 校验附件是否存在，判断 image/document 类型 |
| 条件分支：uploadfile.type in image | 图片走视觉分析；非图片先提取文本 |
| document-extractor | 对 PDF/Word/Excel/TXT/Markdown/CSV/JSON 做文本抽取 |
| 条件分支：issmple == 0 | 选择 qwen2.5vl:7b 兼容路线 |
| 条件分支：issmple != 0 | 选择 qwen3-vl:30b 兼容路线 |
| 变量聚合器 | 只聚合当前分支模型输出 |
| 代码执行 | 移除 `<think>`，截取第一个 `{` 到最后一个 `}`，再做 JSON 标准化 |
| 直接回复 | 只输出最终 JSON，不输出解释 |

## 模型路由

严格保持 Dify 原始分支意图。

### Ollama 服务器

所有模型托管在统一 Ollama 实例：
- **地址**: `http://192.168.70.249:11434/v1`
- **API 格式**: OpenAI-compatible (支持 `/v1/chat/completions`)

如果 Hermes 配置了该 Ollama 服务器的 provider，优先使用指定模型。否则回落当前可用视觉/文档模型，但保留字段规则与 JSON 输出规则。

### 路由表

| 附件类型 | issmple | 目标模型 | 上下文参数 |
|---|---:|---|---|
| image | 0 | qwen2.5vl:7b | num_ctx=5048, num_predict=5048 |
| image | 非 0 | qwen3-vl:30b | num_ctx=5048, num_predict=5048 |
| document | 0 | qwen2.5vl:7b | num_ctx=20480, num_predict=10240 |
| document | 非 0 | qwen3-vl:30b | num_ctx=20480, num_predict=10240 |

> **注意**: 如果当前 Hermes profile 不能在 skill 内部强制切换模型，则使用当前可用的视觉/文档模型执行，但必须保留本 skill 的字段规则与 JSON 输出规则。需要强制模型切换时，应升级为 Hermes plugin/MCP tool，由工具内部调用指定的 OpenAI-compatible endpoint (`http://192.168.70.249:11434/v1`)。

## Hermes Agent 执行约束（必读）

会话里 `[File: xxx.pdf]` 后面跟的 `%PDF-1.7`、`\x00` 等是**给模型看的预览**，不是可执行代码。PDF/Word/Excel/图片是**二进制文件**，禁止下列做法（会触发 `SyntaxError: source code cannot contain null bytes` 或内存溢出）：

| 禁止 | 正确做法 |
|------|----------|
| `execute_code` 里写 `pdf_bytes = b'%PDF...'` 或把附件正文放进 Python 字符串 | **只用 `terminal`** 调用 `extract_text.py`，参数为**磁盘路径** |
| `write_file` 把聊天里的 PDF 原始字节当文本写入 | 附件已由 Hermes 落盘，直接读 `storage_path` |
| `read_file` 读取整份 PDF 再拼进 Prompt/脚本 | 由 `extract_text.py` 在本地读文件并抽文本/调 Ollama |
| 手写 Python 调 Ollama 重复实现解析 | 一条 `terminal` 命令跑 skill 脚本即可 |

### 附件路径解析（在跑脚本之前）

Hermes Panel 上传细节见同目录 `read_file_guide.md`。要点：**Gateway 消息里只有 `[File: 文件名]`，没有 `storage_path`**；真实路径只在 `index.json`。

1. 从用户消息提取文件名（如 `[File: 华尧订单.pdf]` → `华尧订单.pdf`）。
2. 查 `~/.hermes/desktop/chat-attachments/index.json` 中 `attachments[*].name`，使用字段 **`storage_path`**（绝对路径）。磁盘上的 `{uuid}_安全化名` 与显示名可能不同，**禁止手拼路径**。
3. WebOperator / 模板识别场景 `session_id` 多为 `draft_weboperator`（不是 `draft_default`），同名附件多时必须带 session 过滤。
4. 推荐辅助脚本（输出含 `file_exists`）：

```bash
python <skill_dir>/scripts/resolve_attachment_path.py "华尧订单.pdf" --session-id draft_weboperator
```

或当前会话最新 PDF：

```bash
python <skill_dir>/scripts/resolve_attachment_path.py --latest --mime application/pdf --session-id draft_weboperator
```

确认 `ok:true` 且 `file_exists:true` 后，将 `storage_path` 传给 `extract_text.py`（**不要**用 `read_file` 读 PDF 内容，也不要内联到 `execute_code`）。

### 标准 terminal 命令（复制即用）

```bash
python <skill_dir>/scripts/extract_text.py "<storage_path>" --issmple 0
```

带回调时在末尾加 `--callback-url "..."`（见 §3）。

`<skill_dir>` 示例：`C:/Users/Administrator/.hermes/skills/contact_to_order`（以本机 `~/.hermes/skills/contact_to_order` 为准）。

## 执行流程

### 1. 校验附件

确认当前会话中存在 `uploadfile`（或 `index.json` 中能解析到 `storage_path`）。如存在多个附件，逐个解析，最终返回数组形式的 `results`；如只存在一个附件，返回 `{"orderinfo":[...]}`。

### 2. 判断文件类型

- image：jpg、jpeg、png、webp、bmp、tiff、gif，直接走视觉合同解析。
- document：pdf、doc、docx、xls、xlsx、csv、txt、md、json、yaml、yml，先抽取文本再解析。
- 其他类型：提示“不支持该文件类型”，不要编造结果。

### 3. 调用 Ollama 解析（推荐，一步完成）

**仅通过 `terminal` 调用**本目录 `scripts/extract_text.py`（不要用 `execute_code` 内联附件）。脚本按 `model_routes.yaml` 选择模型与 `num_ctx`/`num_predict`，在本地读文件并调用 Ollama，自动清洗 JSON。

```bash
python <skill_dir>/scripts/extract_text.py "<storage_path>" --issmple 0
```

用户提供了回调地址时追加参数（URL 用引号包裹）：

```bash
python <skill_dir>/scripts/extract_text.py <附件绝对路径> --issmple 0 --callback-url "https://your-app.example.com/import?data="
```

- `issmple=0`：image/document 均走 `qwen2.5vl:7b`（document 的 `num_ctx=20480`, `num_predict=10240`；image 为 `5048`/`5048`）。
- `issmple!=0`：走 `qwen3-vl:30b`，上下文参数同上。
- 图片：base64 送入视觉模型；文档：先本地抽文本再送 LLM。
- 成功时 stdout 含 `{"ok":true,"orderinfo":[...],...}`；若带 `--callback-url` 且回调生成成功，还含 `web_url`、`callback_applied:true`。
- **无 callbackURL**：最终对用户只输出 `{"orderinfo":[...]}`。
- **有 callbackURL 且生成 web_url**：最终对用户**只输出一条 Markdown 超链接**（见 §7），不要附加 JSON 或长段说明。

仅调试本地文本抽取（不调用 LLM）：

```bash
python <skill_dir>/scripts/extract_text.py <附件路径> --extract-only
```

若文档抽不出文本或 Ollama 调用失败，必须报错，不得凭文件名猜测合同内容。

### 4. 合同信息抽取 Prompt

由 `extract_text.py` 自动加载 `prompts/contact_to_order_prompt.md` 的 System / User Rules，无需 Agent 手工拼接。

### 5. 输出清洗与标准化

`extract_text.py` 已内联调用 `clean_contact_to_order_json.py` 的规则。若单独拿到模型原始输出，可再执行：

```bash
python <skill_dir>/scripts/clean_contact_to_order_json.py raw_model_output.txt
```

### 6. 最终回复（无回调）

未提供 `callbackURL` 时：最终回复只输出 JSON，不输出分析说明、Markdown 标题、代码块或解释文字。

### 7. 回调 WebUrl（有 callbackURL）

当用户提供了 `callbackURL`，且 `extract_text.py` 返回 `ok:true`、`callback_applied:true`、`web_url` 时：

1. 脚本内部逻辑（与前端 `encodeURIComponent` 一致）：
   - `postData = { "tempType": orderinfo }`（`orderinfo` 为解析得到的数组）
   - `jsonData = encodeURIComponent(JSON.stringify(postData))`
   - `WebUrl = callbackURL + jsonData`
2. 脚本已校验 `callbackURL`（`http`/`https`、含主机名、无非法字符）及拼接后 `WebUrl` 的合法性、长度上限。
3. Agent **仅向用户返回可点击超链接**，格式固定为：

```markdown
[打开订单导入页面](<web_url>)
```

将 `<web_url>` 替换为脚本输出的 `web_url` 字段，不要改写 URL。不要同时粘贴完整 JSON，除非用户明确要求查看原始 `orderinfo`。

若 `callback_applied:false` 或缺少 `web_url`，说明解析失败或 `orderinfo` 无效或 URL 非法，向用户说明 `callback_error` 字段内容，并视情况附上 `orderinfo` JSON。

## 输出 JSON Schema

`orderinfo` 为**数组**，每个元素对应合同中的一行物料；表头字段（客户、订单号、供应商）在每行重复填写。

```json
{
  "orderinfo": [
    {
      "custname": "采购公司名称或 null",
      "orderno": "采购订单号/合同号或 null",
      "supname": "供货公司名称或 null",
      "deliverydate": "YYYY-MM-DD 或 null",
      "partno": "料号/物料编码/型号，去除全部空格，或 null",
      "partdesc": "规格/描述/物料名称/description 或 null",
      "quantity": 0,
      "price": "0.000000 或 null",
      "amount": "0.000000 或 null"
    }
  ]
}
```

## 字段规则

### orderinfo[].custname

采购公司名称。不可从文件名、上传者、聊天上下文推断；合同正文没有则填 `null`。每行物料均填写相同值（若合同有）。

### orderinfo[].orderno

采购订单号、PO号、合同号、订单编号。多个编号时优先选择客户采购订单号，其次合同号；无法确定则填 `null`。每行重复填写。

### orderinfo[].supname

供货公司名称。不可编造；没有则填 `null`。每行重复填写。

### orderinfo[].deliverydate

交货日期必须输出 `YYYY-MM-DD`。若原文只有月份或周数且无法确定具体日期，填 `null`，不要补日期。

### orderinfo[].partno

从“料号、物料代码、物料编码、物料型号、material、材料编码”等字段提取。去掉所有空白字符，包括半角空格、全角空格、Tab、换行。

### orderinfo[].partdesc

从“规格、描述、物料名称、description”等字段提取。保留必要规格文字，不要把单价、数量、日期混入描述。

### orderinfo[].quantity

转为整数类型。必须保持完整数量，不得四舍五入造成数量损失；无法解析则填 `null`。

### orderinfo[].price

单价保留 6 位小数。为避免 JSON number 丢失尾随 0，输出为字符串，例如 `"0.123000"`。为空或无法解析则填 `null`。

如果采购公司或供货公司包含“冠捷”“AOC”“TPV”，且合同中的单价明显按千件/千PCS计价，则单价除以 1000 后再保留 6 位小数。

### orderinfo[].amount

行金额/小计，保留 6 位小数字符串。合同有行金额则直接提取；未给出且 `quantity`、`price` 均有值时，按 `quantity × price` 计算并格式化为 6 位小数。无法解析则填 `null`。

## 禁止事项

- **不得**将 PDF/Office/图片二进制写入 Python 源码、`execute_code`、`write_file` 文本（见「Hermes Agent 执行约束」）。
- 不得编造不存在的客户、供应商、订单号、交期、料号、数量、单价、金额。
- 无 `callbackURL` 时：不得输出中文解释或 Markdown 包装（仅 JSON）。
- 有 `callbackURL` 且已生成 `web_url` 时：只允许输出 §7 规定的单条超链接（可一行简短提示，如「解析完成，请点击打开：」+ 链接）。
- 不得把多个物料合并为一行。
- 不得丢弃小数位；单价与金额需要固定 6 位。
- 不得把 `orderinfo` 输出为对象；必须是数组。
- 不得输出非 JSON 内容（回调成功时的超链接除外）。

## 多附件处理

如用户一次上传多个合同附件，输出：

```json
{
  "results": [
    {
      "file": "原始文件名",
      "orderinfo": []
    }
  ]
}
```

每个附件独立解析，不能跨附件合并客户、订单号和物料。
