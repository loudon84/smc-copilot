SMC Hermes uninstall metadata
